var config = {
    paths: {
        slick: 'js/slick'
    },
    shim: {
        slick: {
            deps: ['jquery']
        }
    },
    deps:['js/main'] 
};